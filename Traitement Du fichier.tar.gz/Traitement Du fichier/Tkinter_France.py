import tkinter as tk  
import matplotlib.pyplot as plt  
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg  # Pour intégrer les graphiques dans Tkinter 
import csv  
import re  #regex pour le dico departements on associe chaque valeur pour chaque code dans NUM_POSTE 
from collections import defaultdict  # Pour utiliser un dictionnaire avec des valeurs par défaut


departements = {
    '09': ['90', '93'],
    '10': ['100', '101', '102', '103', '104'],
    '11': ['11'],
    '12': ['12'],
    '13': ['13'],
    '14': ['14'],
    '15': ['15'],
    '16': ['16'],
    '17': ['17'],
    '18': ['18'],
    '19': ['19'],
    '21': ['21'],
    '22': ['22'],
    '23': ['23'],
    '24': ['24'],
    '25': ['25'],
    '26': ['26'],
    '27': ['27'],
    '28': ['28'],
    '29': ['29'],
    '30': ['30'],
    '31': ['31'],
    '32': ['32'],
    '33': ['33'],
    '34': ['34'],
    '35': ['35'],
    '36': ['36'],
    '37': ['37'],
    '38': ['38'],
    '39': ['39'],
    '40': ['40'],
    '41': ['41'],
    '42': ['42'],
    '43': ['43'],
    '44': ['44'],
    '45': ['45'],
    '46': ['46'],
    '47': ['47'],
    '48': ['48'],
    '49': ['49'],
    '50': ['50'],
    '51': ['51'],
    '52': ['52'],
    '53': ['53'],
    '54': ['54'],
    '55': ['55'],
    '56': ['56'],
    '57': ['57'],
    '58': ['58'],
    '59': ['59'],
    '60': ['60'],
    '61': ['61'],
    '62': ['62'],
    '63': ['63'],
    '64': ['64'],
    '65': ['65'],
    '66': ['66'],
    '67': ['67'],
    '68': ['68'],
    '69': ['69'],
    '70': ['70'],
    '71': ['71'],
    '72': ['72'],
    '73': ['73'],
    '74': ['74'],
    '75': ['75'],
    '76': ['76'],
    '77': ['77'],
    '78': ['78'],
    '79': ['79'],
    '80': ['80'],
    '81': ['81'],
    '82': ['82'],
    '83': ['83'],
    '84': ['84'],
    '85': ['85'],
    '86': ['86'],
    '87': ['87'],
    '88': ['88'],
    '89': ['89'],
    '90': ['900'],
    '91': ['910', '911', '912', '914', '916'],
    '92': ['920'],
    '93': ['930'],
    '94': ['940'],
    '95': ['950', '951', '952', '953', '954', '955', '956']
}

# Fonction pour trouver le département à partir du code postal
def trouver_departement(code_postal):
    code_str = str(code_postal)  
    for departement, prefixe_list in departements.items():  
        # Si le code postal commence par un des préfixes d'un département, retourner ce département grace au dico 
        if any(code_str.startswith(prefix) for prefix in prefixe_list):
            return departement
    return None  # Retourner None si aucun département n'a été trouvé pour évité les erreurs 


def traiter_fichier_csv(fichier_path):
    departements_glots = defaultdict(float)  # Créer un dictionnaire avec valeur par défaut 0.0 pour les totaux GLOT
    with open(fichier_path, 'r', encoding='utf-8') as fichier: 
        lecteur_csv = csv.DictReader(fichier, delimiter=';')  
        for ligne in lecteur_csv:  
            code_postal = ligne['NUM_POSTE']  # Récupérer le code postal de la ligne
            try:
                code_initial = str(code_postal).strip()  # Nettoyer le code postal (enlever espaces)
                
                # Ignorer les codes postaux qui commencent par "01" (pour l'Ain) car pour les codes qui commence en 01 celà bug 
                if code_initial.startswith('01'):
                    continue

                departement = trouver_departement(code_initial)  # Trouver le département pour ce code postal
                
                if departement is None:  # Si le département est inconnu, passer à la ligne suivante
                    continue
                
                glot = float(ligne['GLOT'])  
                departements_glots[departement] += glot  

            except ValueError:  # Si une erreur se produit lors de la conversion des données
                continue        # Passer à la ligne suivante

    return departements_glots  # 



def afficher_diagramme_camembert():
    fichier_path = 'final.csv'  
    resultats_total_glots = traiter_fichier_csv(fichier_path)  
    
    # Créer une nouvelle fenêtre pour afficher le diagramme
    diagramme_window = tk.Toplevel(root)
    diagramme_window.title("Diagramme en Camembert des GLOT par Département")
    
    # Extraire les labels (noms des départements) et les tailles (valeurs de GLOT)
    labels = resultats_total_glots.keys()
    sizes = resultats_total_glots.values()
    
    
    fig, ax = plt.subplots(figsize=(6, 6)) 
    
    # Créer un diagramme en camembert (pie chart) avec les labels et tailles
    ax.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
    ax.axis('equal')  
    
    # Intégrer le graphique dans la fenêtre Tkinter grace à FigureCanvasTkAgg
    canvas = FigureCanvasTkAgg(fig, master=diagramme_window)  
    canvas.draw() 
    canvas.get_tk_widget().pack() 



# Interface tkinter
root = tk.Tk()  
root.title("Analyse des GLOT(UV) de 1950 à 2023")  
root.geometry("800x600")  

#IMAGE
image_path = "../Traitement Du fichier/carte-france-departements.png"  
photo = tk.PhotoImage(file=image_path)  
image_label = tk.Label(root, image=photo)  
image_label.pack(side=tk.LEFT, padx=10, pady=10)  

# coté droite pour les boutons et texte
right_frame = tk.Frame(root)  
right_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=10, pady=10)  


classement_label = tk.Label(right_frame, text="Classement des départements", font=("Arial", 14))  
classement_label.pack()  


classement_text = tk.Text(right_frame, height=10, width=40)  # Zone de texte pour afficher les résultats
classement_text.pack()  

# Boutons de l'interface
button_glot_departement = tk.Button(right_frame, text="GLOT par Département")  
button_glot_departement.pack(pady=5)  

button_glot_region = tk.Button(right_frame, text="GLOT par Région")  
button_glot_region.pack(pady=5)  

button_glot_station = tk.Button(right_frame, text="GLOT par Station")  
button_glot_station.pack(pady=5)  

button_diagramme_camembert = tk.Button(right_frame, text="Afficher Diagramme", command=afficher_diagramme_camembert)
button_diagramme_camembert.pack(pady=5)  

root.mainloop()  

