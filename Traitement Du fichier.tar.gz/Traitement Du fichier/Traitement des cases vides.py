import csv

with open('final.csv', mode='r+', newline='', encoding='utf-8') as file:
    reader = csv.reader(file, delimiter=';') 
    rows = list(reader)  

    # Récupérer l'en-tête et les données
    headers = rows[0]  # Première ligne (en-tête)
    Autre_ligne = rows[1:]  # Toutes les autres lignes

    # Revenir au début pour réécrire les données
    file.seek(0)
    writer = csv.writer(file, delimiter=';')

    # Réécrire l'en-tête
    writer.writerow(headers)

    # Parcourir et modifier les lignes de données
    for row in Autre_ligne:
        for j in range(0, 3):  # Colonnes de 0 à 2 uniquement
            if row[j] == '':
                row[j] = '0'  # Remplacer par '0'
        
        # Réécrire la ligne modifiée
        writer.writerow(row)

    # Tronquer le fichier pour supprimer les données restantes
    file.truncate()
